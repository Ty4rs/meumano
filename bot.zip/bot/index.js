// --- IMPORTAÇÕES ---
process.env.PATH = `${process.env.PATH}:/data/data/com.termux/files/usr/bin`;

const { Client, Events, GatewayIntentBits, EmbedBuilder } = require('discord.js');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const {
    joinVoiceChannel,
    createAudioPlayer,
    createAudioResource,
    AudioPlayerStatus,
    getVoiceConnection,
    VoiceConnectionStatus
} = require('@discordjs/voice');
const play = require('play-dl');
const ytdl = require('@distube/ytdl-core');
require('dotenv').config();

// --- CONFIGURAÇÃO DO COOKIE ---
if (process.env.YT_COOKIE) {
    play.setToken({ youtube: { cookie: process.env.YT_COOKIE } });
}

// --- CONFIGURAÇÕES GERAIS ---
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildVoiceStates,
    ],
});

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const activationKeyword = "criolo";
const queue = new Map();

// --- EVENTO DE BOT PRONTO ---
client.once(Events.ClientReady, readyClient => {
    console.log(`Pronto! Logado como ${readyClient.user.tag}`);
});

// --- EVENTO PRINCIPAL DE MENSAGENS ---
client.on(Events.MessageCreate, async message => {
    if (message.author.bot) return;

    const normalizedContent = message.content.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    const serverQueue = queue.get(message.guild.id);

    if (normalizedContent.includes(activationKeyword)) {
        if (normalizedContent.includes('toque') || normalizedContent.includes('tocar') || normalizedContent.includes('coloque')) {
            const songQuery = message.content.replace(new RegExp(activationKeyword, "ig"), '').replace(/toque|tocar|coloque|a música/ig, '').trim();
            execute(message, songQuery);
        } else if (normalizedContent.includes('pause') || normalizedContent.includes('pausar')) {
            pause(message, serverQueue);
        } else if (normalizedContent.includes('continue') || normalizedContent.includes('continuar')) {
            resume(message, serverQueue);
        } else if (normalizedContent.includes('pular') || normalizedContent.includes('proxima')) {
            skip(message, serverQueue);
        } else if (normalizedContent.includes('parar') || normalizedContent.includes('pare')) {
            stop(message, serverQueue);
        } 
        else if (normalizedContent.includes('fazer uma enquete')) {
            const themeMatch = message.content.match(/tema:\s*"(.*?)"/i);
            const timeMatch = message.content.match(/tempo:\s*(\d*\.?\d+)/i);
            const theme = themeMatch ? themeMatch[1] : null;
            const time = timeMatch ? parseFloat(timeMatch[1].replace(',', '.')) : null;

            if (theme && time) {
                startPoll(message, theme, time);
            } else {
                message.reply('Formato da enquete inválido. Use: `criolo fazer uma enquete tema: "Seu tema aqui" tempo: 5.5`.');
            }
        }
        else {
            await message.channel.sendTyping();
            const userPrompt = message.content.replace(new RegExp(activationKeyword, "ig"), '').trim();
            if (!userPrompt) return;
            try {
                const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
                const result = await model.generateContent(userPrompt);
                const response = await result.response;
                const text = response.text();
                if (text.length <= 2000) {
                    await message.reply(text);
                } else {
                    const chunks = text.match(/[\s\S]{1,1990}/g) || [];
                    for (const chunk of chunks) { await message.channel.send(chunk); }
                }
            } catch (error) {
                console.error("Erro na API do Gemini:", error);
                if (error.status !== 429) {
                    await message.reply("Ocorreu um erro ao processar sua solicitação.");
                }
            }
        }
    }
});


// --- FUNÇÕES DE MÚSICA ---
async function execute(message, songQuery) {
    const serverQueue = queue.get(message.guild.id);
    const voiceChannel = message.member.voice.channel;
    if (!voiceChannel) return message.channel.send("Você precisa estar em um canal de voz para tocar música!");
    if (!songQuery) return message.channel.send("Por favor, diga o nome da música!");
    const permissions = voiceChannel.permissionsFor(message.client.user);
    if (!permissions.has("CONNECT") || !permissions.has("SPEAK")) {
        return message.channel.send("Preciso de permissão para entrar e falar no seu canal de voz!");
    }
    try {
        const searchResults = await play.search(songQuery, { limit: 1, source: { youtube: 'video' } });
        if (!searchResults.length) return message.channel.send(`Não encontrei vídeos para "${songQuery}".`);
        const song = { title: searchResults[0].title, url: searchResults[0].url };
        if (!serverQueue) {
            const player = createAudioPlayer();
            player.on(AudioPlayerStatus.Idle, () => {
                const oldQueue = queue.get(message.guild.id);
                if (oldQueue) {
                    oldQueue.songs.shift();
                    if (oldQueue.songs.length > 0) {
                        playSong(message.guild, oldQueue.songs[0]);
                    } else {
                        oldQueue.textChannel.send('Fila de músicas terminada. Desconectando em 5 segundos...');
                        setTimeout(() => {
                            const conn = getVoiceConnection(message.guild.id);
                            if (conn) conn.destroy();
                        }, 5000);
                    }
                }
            });
            player.on('error', error => {
                console.error(`Erro no player: ${error.message}`);
                queue.get(message.guild.id)?.textChannel.send('Ocorreu um erro, pulando para a próxima faixa.');
                player.stop(true);
            });
            const queueContruct = {
                textChannel: message.channel,
                voiceChannel: voiceChannel,
                connection: null,
                songs: [song],
                player: player,
            };
            queue.set(message.guild.id, queueContruct);
            const connection = joinVoiceChannel({
                channelId: voiceChannel.id,
                guildId: message.guild.id,
                adapterCreator: message.guild.voiceAdapterCreator,
            });
            connection.on(VoiceConnectionStatus.Destroyed, () => {
                console.log(`Conexão destruída para o servidor ${message.guild.id}, limpando a fila.`);
                queue.delete(message.guild.id);
            });
            queueContruct.connection = connection;
            connection.subscribe(player);
            playSong(message.guild, queueContruct.songs[0]);
        } else {
            serverQueue.songs.push(song);
            return message.channel.send(`**${song.title}** foi adicionada à fila!`);
        }
    } catch (e) {
        console.error("Erro na execução:", e);
        message.channel.send("Ocorreu um erro ao buscar sua música.");
    }
}
function playSong(guild, song) {
    const serverQueue = queue.get(guild.id);
    if (!serverQueue || !song) {
        const conn = getVoiceConnection(guild.id);
        if (conn) conn.destroy();
        return;
    }
    try {
        console.log(`Tentando tocar: ${song.title}`);
        const stream = ytdl(song.url, { filter: 'audioonly', quality: 'highestaudio', highWaterMark: 1 << 25, });
        const resource = createAudioResource(stream);
        serverQueue.player.play(resource);
        serverQueue.textChannel.send(`Começando a tocar: **${song.title}**`);
    } catch (error) {
        console.error("Erro ao criar o stream com ytdl:", error);
        serverQueue.textChannel.send(`Não foi possível tocar **${song.title}**. Pulando.`);
        serverQueue.player.stop(true);
    }
}
function pause(message, serverQueue) {
    if (!message.member.voice.channel) return message.channel.send("Você precisa estar em um canal de voz!");
    if (!serverQueue || !serverQueue.player) return message.channel.send("Não há nada tocando!");
    if (serverQueue.player.state.status === AudioPlayerStatus.Paused) return message.channel.send("A música já está pausada!");
    serverQueue.player.pause();
    message.channel.send("Música pausada! ⏸️");
}
function resume(message, serverQueue) {
    if (!message.member.voice.channel) return message.channel.send("Você precisa estar em um canal de voz!");
    if (!serverQueue || !serverQueue.player) return message.channel.send("Não há nada para continuar!");
    if (serverQueue.player.state.status === AudioPlayerStatus.Playing) return message.channel.send("A música já está tocando!");
    serverQueue.player.unpause();
    message.channel.send("Continuando a música! ▶️");
}
function stop(message, serverQueue) {
    if (!message.member.voice.channel) return message.channel.send("Você precisa estar em um canal de voz!");
    if (!serverQueue) return message.channel.send("Não há nada tocando para eu parar!");
    serverQueue.songs = [];
    if (serverQueue.connection && serverQueue.connection.state.status !== VoiceConnectionStatus.Destroyed) {
        serverQueue.connection.destroy();
    }
    message.channel.send("Música parada e fila limpa! ⏹️");
}
function skip(message, serverQueue) {
    if (!message.member.voice.channel) return message.channel.send("Você precisa estar em um canal de voz!");
    if (!serverQueue || !serverQueue.player) return message.channel.send("Não há música para pular!");
    message.channel.send("Música pulada! ⏭️");
    serverQueue.player.stop(true);
}
// --- FIM DAS FUNÇÕES DE MÚSICA ---


// --- FUNÇÃO DE ENQUETE ATUALIZADA ---
async function startPoll(message, theme, durationInMinutes) {
    const pollEmbed = new EmbedBuilder()
        .setColor(0x0099FF)
        .setTitle('📊 Enquete Iniciada!')
        .setDescription(`**Tema:** ${theme}`)
        .addFields(
            { name: 'A Favor', value: '👍', inline: true },
            { name: 'Contra', value: '👎', inline: true }
        )
        .setTimestamp()
        .setFooter({ text: `A votação termina em ${durationInMinutes} minuto(s).` });

    try {
        const pollMessage = await message.channel.send({ embeds: [pollEmbed] });
        await pollMessage.react('👍');
        await pollMessage.react('👎');

        const filter = (reaction, user) => {
            return ['👍', '👎'].includes(reaction.emoji.name) && !user.bot;
        };

        const collector = pollMessage.createReactionCollector({ filter, time: durationInMinutes * 60 * 1000 });

        collector.on('end', collected => {
            const forVotes = (collected.get('👍')?.count || 0);
            const againstVotes = (collected.get('👎')?.count || 0);

            let resultText = '';
            let color = 0x808080; // Cinza para empate

            if (forVotes > againstVotes) {
                resultText = 'O resultado foi **A FAVOR**! ✅';
                color = 0x00FF00; // Verde
            } else if (againstVotes > forVotes) {
                resultText = 'O resultado foi **CONTRA**! ❌';
                color = 0xFF0000; // Vermelho
            } else {
                resultText = 'A votação terminou em **EMPATE**! 🤝';
            }

            const resultEmbed = new EmbedBuilder()
                .setColor(color)
                .setTitle('📊 Enquete Finalizada!')
                .setDescription(`**Tema:** ${theme}`)
                .addFields(
                    { name: 'Votos a Favor', value: `${forVotes} votos`, inline: true },
                    { name: 'Votos Contra', value: `${againstVotes} votos`, inline: true },
                    { name: 'Resultado', value: resultText }
                )
                .setTimestamp()
                .setFooter({ text: 'Votação encerrada.' });

            pollMessage.edit({ embeds: [resultEmbed] });
        });
    } catch (e) {
        console.error("Erro ao criar a enquete:", e);
        message.channel.send("Não consegui criar a enquete. Verifique minhas permissões para enviar mensagens, criar embeds e adicionar reações.");
    }
}


// --- LOGIN DO BOT ---
client.login(process.env.DISCORD_TOKEN);